const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
let creatingDocument;
export async function ensureOffscreenDocument() {
    if (!("offscreen" in chrome)) {
        throw new Error("This Chrome version does not support offscreen documents.");
    }
    if (await hasOffscreenDocument()) {
        return;
    }
    if (!creatingDocument) {
        creatingDocument = chrome.offscreen.createDocument({
            url: OFFSCREEN_DOCUMENT_PATH,
            reasons: ["BLOBS"],
            justification: "Create a temporary ZIP Blob URL for captured PNG files.",
        });
    }
    try {
        await creatingDocument;
    }
    finally {
        creatingDocument = undefined;
    }
}
export async function sendToOffscreen(message) {
    const response = await chrome.runtime.sendMessage(message);
    if (!response || response.ok !== true) {
        throw new Error(response?.error ?? "The offscreen document did not respond.");
    }
    return response;
}
async function hasOffscreenDocument() {
    const runtime = chrome.runtime;
    if (typeof runtime.getContexts === "function") {
        const contexts = await runtime.getContexts({
            contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
            documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)],
        });
        return contexts.length > 0;
    }
    const serviceWorkerScope = globalThis;
    if (!serviceWorkerScope.clients) {
        return false;
    }
    const clients = await serviceWorkerScope.clients.matchAll({ includeUncontrolled: true });
    const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
    return clients.some((client) => client.url === offscreenUrl);
}
