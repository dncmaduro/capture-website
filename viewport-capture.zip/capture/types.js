export const CAPTURE_MENU_ID = "viewport-capture";
export const MAX_SCREENSHOTS = 200;
